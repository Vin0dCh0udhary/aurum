"use strict";

const express        = require("express");
const router         = express.Router();
const pgConfig       = require("../config/pgConfig");
const paymentService = require("../service/paymentService");

// ── GET /api/config  →  Return public config (merchantId, aggregatorId, txnId, txnDate)
router.get("/config", (req, res) => {
  res.json({
    uatMerchantId:    pgConfig.uat.merchantId,
    uatAggregatorId:  pgConfig.uat.aggregatorId,
    liveMerchantId:   pgConfig.live.merchantId,
    liveAggregatorId: pgConfig.live.aggregatorId,
    transactionId:    paymentService.generateTransactionId(),
    txnDate:          paymentService.generateTxnDate(),
  });
});

// ── POST /api/payment/submit  →  Initiate Sale
router.post("/payment/submit", async (req, res) => {
  try {
    const result = await paymentService.initiateSale(req.body);
    res.json(result);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── POST /api/status/submit  →  Check Status
router.post("/status/submit", async (req, res) => {
  const { environment, transactionid, originalid } = req.body;
  try {
    const responseData = await paymentService.checkStatus(
      environment, transactionid, originalid
    );
    res.json({ responseData });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── POST /api/refund/submit  →  Initiate Refund
router.post("/refund/submit", async (req, res) => {
  const { environment, transactionid, originalid, amount } = req.body;
  try {
    const responseData = await paymentService.initiateRefund(
      environment, transactionid, originalid, amount
    );
    res.json({ responseData, amount });
  } catch (err) {
    res.status(500).json({ error: err.message, amount });
  }
});

// ── GET /api/generate-txn  →  Generate fresh transaction ID + date
router.get("/generate-txn", (req, res) => {
  res.json({
    transactionId: paymentService.generateTransactionId(),
    txnDate:       paymentService.generateTxnDate(),
  });
});

module.exports = router;
