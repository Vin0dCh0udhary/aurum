"use strict";

require("dotenv").config();

const config = {
  port: process.env.PORT || 3000,
  timezone: process.env.TZ || "Asia/Kolkata",

  uat: {
    merchantId:   process.env.UAT_MERCHANT_ID,
    aggregatorId: process.env.UAT_AGGREGATOR_ID,
    secretKey:    process.env.UAT_SECRET_KEY,
    returnUrl:    process.env.UAT_RETURN_URL,
    api: {
      initiateSale: process.env.UAT_API_INITIATE_SALE,
      status:       process.env.UAT_API_STATUS,
      refund:       process.env.UAT_API_REFUND,
    },
  },

  live: {
    merchantId:   process.env.LIVE_MERCHANT_ID,
    aggregatorId: process.env.LIVE_AGGREGATOR_ID,
    secretKey:    process.env.LIVE_SECRET_KEY,
    returnUrl:    process.env.LIVE_RETURN_URL,
    api: {
      initiateSale: process.env.LIVE_API_INITIATE_SALE,
      status:       process.env.LIVE_API_STATUS,
      refund:       process.env.LIVE_API_REFUND,
    },
  },

  forEnv(env) {
    if (typeof env === "string" && env.toUpperCase() === "LIVE") {
      return this.live;
    }
    return this.uat;
  },
};

module.exports = config;
