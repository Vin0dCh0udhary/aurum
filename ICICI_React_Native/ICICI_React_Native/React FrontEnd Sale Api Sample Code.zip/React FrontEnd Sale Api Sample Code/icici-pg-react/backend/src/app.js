"use strict";

const express   = require("express");
const cors      = require("cors");
const pgConfig  = require("./config/pgConfig");
const apiRoutes = require("./routes/apiRoutes");

const app = express();

// ── CORS — allow React dev server (port 5173) and production
app.use(cors({
  origin: [
    "http://localhost:5173",
    "http://localhost:3000",
    "http://localhost:4173",
  ],
  methods: ["GET", "POST"],
}));

// ── Body parsers
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// ── API Routes
app.use("/api", apiRoutes);

// ── Health check
app.get("/health", (_req, res) => res.json({ status: "ok" }));

// ── Global error handler
app.use((err, _req, res, _next) => {
  console.error("[ICICI PG Error]", err);
  res.status(500).json({ error: err.message });
});

// ── Start server
const PORT = pgConfig.port || 3000;
app.listen(PORT, () => {
  console.log(`\n🚀 ICICI PG Backend API running on http://localhost:${PORT}\n`);
  console.log("  API Endpoints:");
  console.log(`    GET  http://localhost:${PORT}/api/config`);
  console.log(`    POST http://localhost:${PORT}/api/payment/submit`);
  console.log(`    POST http://localhost:${PORT}/api/status/submit`);
  console.log(`    POST http://localhost:${PORT}/api/refund/submit`);
  console.log(`    GET  http://localhost:${PORT}/api/generate-txn\n`);
});

module.exports = app;
