"use strict";

const axios          = require("axios");
const pgConfig       = require("../config/pgConfig");
const { hmacSha256 } = require("./hashUtil");

function getNowFormatted() {
  const now   = new Date();
  const parts = new Intl.DateTimeFormat("en-IN", {
    timeZone: pgConfig.timezone,
    year: "numeric", month: "2-digit", day: "2-digit",
    hour: "2-digit", minute: "2-digit", second: "2-digit",
    hour12: false,
  }).formatToParts(now);

  const p = {};
  parts.forEach(({ type, value }) => { p[type] = value; });
  return `${p.year}${p.month}${p.day}${p.hour}${p.minute}${p.second}`;
}

async function postJson(url, payload) {
  const response = await axios.post(url, payload, {
    headers: { "Content-Type": "application/json" },
    timeout: 30000,
  });
  return response.data;
}

const nvl = (s) => (s == null ? "" : String(s));

function generateTransactionId() {
  return "test" + getNowFormatted();
}

function generateTxnDate() {
  return getNowFormatted();
}

async function initiateSale(saleRequest) {
  const {
    environment, name, mobile, email,
    amount, transactionId, txnDate,
    addlParam1, addlParam2,
    udf1, udf2, udf3,
  } = saleRequest;

  const env = pgConfig.forEnv(environment);

  const fields = {
    addlParam1:       nvl(addlParam1),
    addlParam2:       nvl(addlParam2),
    aggregatorID:     env.aggregatorId,
    amount:           nvl(amount),
    currencyCode:     "356",
    customerEmailID:  nvl(email),
    customerMobileNo: nvl(mobile),
    customerName:     nvl(name),
    merchantId:       env.merchantId,
    merchantTxnNo:    nvl(transactionId),
    payType:          "0",
    returnURL:        env.returnUrl,
    transactionType:  "SALE",
    txnDate:          nvl(txnDate),
  };

  let udfFields = null;
  const hasUdf = udf1 || udf2 || udf3;
  if (hasUdf) {
    udfFields = [{ udf21: nvl(udf1), udf22: nvl(udf2), udf23: nvl(udf3) }];
    fields.udfFields = udfFields;
  }

  const sortedKeys = Object.keys(fields).sort();
  let dataToHash   = "";
  for (const key of sortedKeys) {
    if (key === "udfFields" && udfFields) {
      dataToHash += JSON.stringify(udfFields);
    } else {
      dataToHash += fields[key];
    }
  }

  const secureHash = hmacSha256(dataToHash, env.secretKey);

  const payload = {};
  for (const key of sortedKeys) {
    payload[key] = fields[key];
  }
  payload.secureHash = secureHash;

  const jsonPayload = JSON.stringify(payload);
  const rawResponse = await postJson(env.api.initiateSale, payload);

  const result = { jsonPayload, dataToHash, rawResponse, success: false };
  if (rawResponse.redirectURI && rawResponse.tranCtx) {
    result.redirectUrl = `${rawResponse.redirectURI}?tranCtx=${rawResponse.tranCtx}`;
    result.success     = true;
  }

  return result;
}

async function checkStatus(environment, transactionId, originalId) {
  const env = pgConfig.forEnv(environment);

  const data = {
    aggregatorID:    env.aggregatorId,
    merchantId:      env.merchantId,
    merchantTxnNo:   transactionId,
    originalTxnNo:   originalId,
    transactionType: "STATUS",
  };

  const dataToHash = Object.keys(data).sort().map((k) => data[k]).join("");
  const secureHash = hmacSha256(dataToHash, env.secretKey);
  const payload    = { ...data, secureHash };

  return postJson(env.api.status, payload);
}

async function initiateRefund(environment, transactionId, originalId, amount) {
  const env             = pgConfig.forEnv(environment);
  const formattedAmount = parseFloat(amount).toFixed(2);

  const data = {
    aggregatorID:    env.aggregatorId,
    amount:          formattedAmount,
    merchantId:      env.merchantId,
    merchantTxnNo:   transactionId,
    originalTxnNo:   originalId,
    transactionType: "REFUND",
  };

  const dataToHash = Object.keys(data).sort().map((k) => data[k]).join("");
  const secureHash = hmacSha256(dataToHash, env.secretKey);
  const payload    = { ...data, secureHash };

  return postJson(env.api.refund, payload);
}

module.exports = {
  generateTransactionId,
  generateTxnDate,
  initiateSale,
  checkStatus,
  initiateRefund,
};
