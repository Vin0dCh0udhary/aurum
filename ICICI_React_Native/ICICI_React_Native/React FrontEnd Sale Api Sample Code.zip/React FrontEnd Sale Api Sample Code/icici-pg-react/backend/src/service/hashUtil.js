"use strict";

const crypto = require("crypto");

/**
 * Generates an HMAC-SHA256 hex digest.
 * @param {string} data      - concatenated string to hash
 * @param {string} secretKey - merchant secret key
 * @returns {string}         - lowercase hex digest
 */
function hmacSha256(data, secretKey) {
  return crypto
    .createHmac("sha256", secretKey)
    .update(data, "utf8")
    .digest("hex");
}

module.exports = { hmacSha256 };
