import React from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import {
  PageShell, Card, PageTitle, ResponseTable, JsonBlock, Alert
} from '../components/UI.jsx';

export default function PaymentResponse() {
  const [searchParams] = useSearchParams();

  // Collect all query params (GET callback from ICICI)
  const responseData = Object.fromEntries(searchParams.entries());
  const hasData = Object.keys(responseData).length > 0;

  // Determine status for alert type
  const txnStatus = responseData.TxnStatus || responseData.txnStatus || responseData.status || '';
  const isSuccess = /success|S/i.test(txnStatus);
  const isFailed  = /fail|F|decline/i.test(txnStatus);

  return (
    <PageShell>
      <Card maxWidth={700}>
        <PageTitle
          icon={isSuccess ? '✅' : isFailed ? '❌' : '📋'}
          title="Payment Response"
          subtitle="Callback received from ICICI Payment Gateway"
        />

        {isSuccess && <Alert type="success">Payment completed successfully!</Alert>}
        {isFailed  && <Alert type="error">Payment failed or was declined.</Alert>}
        {!hasData  && (
          <Alert type="warning">
            No response data found. This page is typically loaded by ICICI PG after payment.
          </Alert>
        )}

        {hasData && (
          <>
            <ResponseTable data={responseData} />
            <JsonBlock data={responseData} label="Raw JSON Response" />
          </>
        )}

        <div style={{ marginTop: 24, display: 'flex', gap: 16 }}>
          <Link to="/" style={{
            padding: '9px 18px',
            background: 'var(--primary)',
            color: '#fff',
            borderRadius: 7,
            fontWeight: 600,
            fontSize: '0.9rem',
            textDecoration: 'none',
          }}>← New Payment</Link>
          <Link to="/status" style={{
            padding: '9px 18px',
            background: 'var(--surface)',
            color: 'var(--primary)',
            border: '1.5px solid var(--border)',
            borderRadius: 7,
            fontWeight: 600,
            fontSize: '0.9rem',
            textDecoration: 'none',
          }}>🔍 Check Status</Link>
        </div>
      </Card>
    </PageShell>
  );
}
