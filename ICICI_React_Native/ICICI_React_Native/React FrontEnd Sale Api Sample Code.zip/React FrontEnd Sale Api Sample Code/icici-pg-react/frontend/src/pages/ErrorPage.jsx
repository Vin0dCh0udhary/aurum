import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { PageShell, Card, PageTitle, Alert, JsonBlock } from '../components/UI.jsx';

export default function ErrorPage() {
  const location = useLocation();
  const { error, debug } = location.state || {};

  // Also check sessionStorage for debug info set by InitiateSale
  let debugInfo = debug;
  if (!debugInfo) {
    try {
      const stored = sessionStorage.getItem('pg_error_debug');
      if (stored) {
        debugInfo = JSON.parse(stored);
        sessionStorage.removeItem('pg_error_debug');
      }
    } catch (_) {}
  }

  return (
    <PageShell>
      <Card maxWidth={700}>
        <PageTitle icon="❌" title="Payment Error" />

        <Alert type="error">
          {error || 'An unexpected error occurred during payment processing.'}
        </Alert>

        {debugInfo?.jsonPayload && (
          <JsonBlock data={debugInfo.jsonPayload} label="JSON Payload Sent to PG" />
        )}
        {debugInfo?.dataToHash && (
          <JsonBlock data={debugInfo.dataToHash} label="Data to Hash (pre-HMAC)" />
        )}
        {debugInfo?.rawResponse && (
          <JsonBlock data={debugInfo.rawResponse} label="Raw PG API Response" />
        )}

        <div style={{ marginTop: 24, display: 'flex', gap: 12 }}>
          <Link to="/" style={{
            padding: '9px 18px',
            background: 'var(--primary)',
            color: '#fff',
            borderRadius: 7,
            fontWeight: 600,
            fontSize: '0.9rem',
            textDecoration: 'none',
          }}>← Try Again</Link>
        </div>
      </Card>
    </PageShell>
  );
}
