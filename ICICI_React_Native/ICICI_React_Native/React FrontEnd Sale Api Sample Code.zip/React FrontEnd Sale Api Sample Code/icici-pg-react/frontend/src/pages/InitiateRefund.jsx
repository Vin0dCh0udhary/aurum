import React, { useState, useEffect } from 'react';
import { api } from '../utils/api.js';
import {
  PageShell, Card, PageTitle, Field, Input, Select,
  SubmitButton, Alert, ResponseTable, JsonBlock, Divider
} from '../components/UI.jsx';

export default function InitiateRefund() {
  const [config, setConfig]         = useState(null);
  const [loading, setLoading]       = useState(false);
  const [error, setError]           = useState('');
  const [responseData, setResponseData] = useState(null);
  const [refundAmount, setRefundAmount] = useState('');
  const [env, setEnv]               = useState('UAT');

  const [form, setForm] = useState({
    transactionid: '',
    originalid: '',
    amount: '',
  });

  useEffect(() => {
    api.getConfig().then(setConfig).catch(e => setError(e.message));
  }, []);

  const merchantId   = env === 'LIVE' ? config?.liveMerchantId   : config?.uatMerchantId;
  const aggregatorId = env === 'LIVE' ? config?.liveAggregatorId : config?.uatAggregatorId;

  function handleChange(e) {
    const { name, value } = e.target;
    setForm(f => ({ ...f, [name]: value }));
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setLoading(true);
    setError('');
    setResponseData(null);

    try {
      // Backend auto-generates a new transaction ID for the refund
      const txnResult = await api.generateTxn();
      const result    = await api.initiateRefund({
        environment:   env,
        transactionid: txnResult.transactionId,
        originalid:    form.originalid,
        amount:        form.amount,
      });

      setResponseData(result.responseData);
      setRefundAmount(result.amount);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <PageShell>
      <Card maxWidth={500}>
        <PageTitle
          icon="↩️"
          title="Initiate Refund"
          subtitle="Process a full or partial refund for a completed transaction"
        />

        {error && <Alert type="error">{error}</Alert>}

        <form onSubmit={handleSubmit}>
          <Field label="Environment" required>
            <Select value={env} onChange={e => setEnv(e.target.value)}>
              <option value="UAT">UAT (Testing)</option>
              <option value="LIVE">LIVE (Production)</option>
            </Select>
          </Field>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
            <Field label="Merchant ID">
              <Input value={merchantId || '...'} readOnly />
            </Field>
            <Field label="Aggregator ID">
              <Input value={aggregatorId || '...'} readOnly />
            </Field>
          </div>

          <Divider label="Refund Details" />

          <Field label="Original Transaction No" required>
            <Input
              type="text"
              name="originalid"
              value={form.originalid}
              onChange={handleChange}
              placeholder="Enter Original Txn No to refund"
              required
            />
          </Field>

          <Field label="Refund Amount (₹)" required>
            <Input
              type="number"
              name="amount"
              value={form.amount}
              onChange={handleChange}
              placeholder="Enter refund amount"
              step="0.01"
              min="0.01"
              required
            />
          </Field>

          <div style={{
            background: 'var(--warn-bg)',
            border: '1px solid #fcd34d',
            borderRadius: 7,
            padding: '10px 14px',
            fontSize: '0.82rem',
            color: 'var(--warn)',
            marginBottom: 12,
          }}>
            💡 A new transaction ID will be auto-generated for this refund request.
          </div>

          <SubmitButton loading={loading}>
            {loading ? 'Processing Refund...' : '↩️ Initiate Refund'}
          </SubmitButton>
        </form>
      </Card>

      {/* Response Section */}
      {responseData && (
        <Card maxWidth={700} style={{ marginTop: 24 }}>
          <PageTitle icon="📋" title="Refund Response" />
          {refundAmount && (
            <Alert type="info">Refund of ₹{refundAmount} submitted to ICICI PG.</Alert>
          )}
          <ResponseTable data={responseData} />
          <JsonBlock data={responseData} label="Raw JSON Response" />
          <div style={{ marginTop: 16, display: 'flex', gap: 12 }}>
            <button
              onClick={() => { setResponseData(null); setForm({ transactionid: '', originalid: '', amount: '' }); }}
              style={{
                padding: '8px 16px',
                background: 'var(--primary)',
                border: 'none',
                borderRadius: 7,
                color: '#fff',
                cursor: 'pointer',
                fontSize: '0.85rem',
                fontWeight: 600,
              }}
            >
              ← New Refund
            </button>
          </div>
        </Card>
      )}
    </PageShell>
  );
}
