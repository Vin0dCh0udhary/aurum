import React, { useState, useEffect } from 'react';
import { api } from '../utils/api.js';
import {
  PageShell, Card, PageTitle, Field, Input, Select, SubmitButton, Alert, Divider
} from '../components/UI.jsx';

export default function InitiateSale() {
  const [config, setConfig]   = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError]     = useState('');
  const [env, setEnv]         = useState('UAT');

  const [form, setForm] = useState({
    name: '', mobile: '', email: '',
    amount: '', addlParam1: '', addlParam2: '',
    udf1: '', udf2: '', udf3: '',
  });

  useEffect(() => {
    api.getConfig().then(setConfig).catch(e => setError(e.message));
  }, []);

  const merchantId    = env === 'LIVE' ? config?.liveMerchantId    : config?.uatMerchantId;
  const aggregatorId  = env === 'LIVE' ? config?.liveAggregatorId  : config?.uatAggregatorId;

  function handleChange(e) {
    const { name, value } = e.target;
    setForm(f => ({ ...f, [name]: value }));
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      const result = await api.submitPayment({
        environment: env,
        ...form,
        transactionId: config.transactionId,
        txnDate:       config.txnDate,
      });

      if (result.success && result.redirectUrl) {
        window.location.href = result.redirectUrl;
      } else {
        setError('Payment gateway did not return a redirect URL. Check the debug info below.');
        // store debug info in session for error page
        sessionStorage.setItem('pg_error_debug', JSON.stringify(result));
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <PageShell>
      <Card maxWidth={500}>
        <PageTitle
          icon="💳"
          title="Initiate Sale"
          subtitle="Submit a new payment transaction to ICICI PG"
        />

        {error && <Alert type="error">{error}</Alert>}

        <form onSubmit={handleSubmit}>
          {/* Environment */}
          <Field label="Environment" required>
            <Select
              value={env}
              onChange={e => setEnv(e.target.value)}
              required
            >
              <option value="UAT">UAT (Testing)</option>
              <option value="LIVE">LIVE (Production)</option>
            </Select>
          </Field>

          {/* Auto-filled IDs */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
            <Field label="Merchant ID">
              <Input value={merchantId || '...'} readOnly />
            </Field>
            <Field label="Aggregator ID">
              <Input value={aggregatorId || '...'} readOnly />
            </Field>
          </div>

          <Divider label="Customer Details" />

          <Field label="Full Name" required>
            <Input
              type="text"
              name="name"
              value={form.name}
              onChange={handleChange}
              placeholder="Enter customer name"
              required
            />
          </Field>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
            <Field label="Mobile Number" required>
              <Input
                type="tel"
                name="mobile"
                value={form.mobile}
                onChange={handleChange}
                placeholder="10-digit mobile"
                pattern="[0-9]{10}"
                maxLength={10}
                required
              />
            </Field>
            <Field label="Email Address">
              <Input
                type="email"
                name="email"
                value={form.email}
                onChange={handleChange}
                placeholder="user@example.com"
              />
            </Field>
          </div>

          <Field label="Payment Amount (₹)" required>
            <Input
              type="number"
              name="amount"
              value={form.amount}
              onChange={handleChange}
              placeholder="e.g. 100.00"
              step="0.01"
              min="1"
              required
            />
          </Field>

          <Divider label="Additional Parameters (Optional)" />

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
            <Field label="Addl Param 1">
              <Input name="addlParam1" value={form.addlParam1} onChange={handleChange} placeholder="Optional" />
            </Field>
            <Field label="Addl Param 2">
              <Input name="addlParam2" value={form.addlParam2} onChange={handleChange} placeholder="Optional" />
            </Field>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 12 }}>
            <Field label="UDF 1">
              <Input name="udf1" value={form.udf1} onChange={handleChange} placeholder="Optional" />
            </Field>
            <Field label="UDF 2">
              <Input name="udf2" value={form.udf2} onChange={handleChange} placeholder="Optional" />
            </Field>
            <Field label="UDF 3">
              <Input name="udf3" value={form.udf3} onChange={handleChange} placeholder="Optional" />
            </Field>
          </div>

          {/* Hidden / auto txn info */}
          {config && (
            <div style={{
              background: 'var(--primary-lt)',
              borderRadius: 7,
              padding: '10px 14px',
              fontSize: '0.8rem',
              color: 'var(--primary)',
              marginTop: 4, marginBottom: 12,
            }}>
              <strong>Txn ID:</strong> {config.transactionId} &nbsp;·&nbsp;
              <strong>Date:</strong> {config.txnDate}
            </div>
          )}

          <SubmitButton loading={loading}>
            {loading ? 'Processing...' : '🚀 Submit Payment'}
          </SubmitButton>
        </form>
      </Card>
    </PageShell>
  );
}
