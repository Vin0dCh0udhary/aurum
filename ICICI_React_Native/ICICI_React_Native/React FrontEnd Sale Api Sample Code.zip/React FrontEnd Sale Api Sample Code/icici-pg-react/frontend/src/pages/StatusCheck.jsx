import React, { useState, useEffect } from 'react';
import { api } from '../utils/api.js';
import {
  PageShell, Card, PageTitle, Field, Input, Select,
  SubmitButton, Alert, ResponseTable, JsonBlock, Divider
} from '../components/UI.jsx';

export default function StatusCheck() {
  const [config, setConfig]         = useState(null);
  const [loading, setLoading]       = useState(false);
  const [error, setError]           = useState('');
  const [responseData, setResponseData] = useState(null);
  const [env, setEnv]               = useState('UAT');

  const [form, setForm] = useState({
    transactionid: '',
    originalid: '',
  });

  useEffect(() => {
    api.getConfig().then(setConfig).catch(e => setError(e.message));
  }, []);

  const merchantId   = env === 'LIVE' ? config?.liveMerchantId   : config?.uatMerchantId;
  const aggregatorId = env === 'LIVE' ? config?.liveAggregatorId : config?.uatAggregatorId;

  function handleChange(e) {
    const { name, value } = e.target;
    setForm(f => ({ ...f, [name]: value }));
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setLoading(true);
    setError('');
    setResponseData(null);

    try {
      const result = await api.checkStatus({ environment: env, ...form });
      setResponseData(result.responseData);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <PageShell>
      <Card maxWidth={500}>
        <PageTitle
          icon="🔍"
          title="Check Transaction Status"
          subtitle="Query the current status of a previously initiated transaction"
        />

        {error && <Alert type="error">{error}</Alert>}

        <form onSubmit={handleSubmit}>
          <Field label="Environment" required>
            <Select value={env} onChange={e => setEnv(e.target.value)}>
              <option value="UAT">UAT (Testing)</option>
              <option value="LIVE">LIVE (Production)</option>
            </Select>
          </Field>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
            <Field label="Merchant ID">
              <Input value={merchantId || '...'} readOnly />
            </Field>
            <Field label="Aggregator ID">
              <Input value={aggregatorId || '...'} readOnly />
            </Field>
          </div>

          <Divider label="Transaction Details" />

          <Field label="Merchant Txn No" required>
            <Input
              type="text"
              name="transactionid"
              value={form.transactionid}
              onChange={handleChange}
              placeholder="Enter Merchant Transaction No"
              required
            />
          </Field>

          <Field label="Original Txn No" required>
            <Input
              type="text"
              name="originalid"
              value={form.originalid}
              onChange={handleChange}
              placeholder="Enter Original Transaction No"
              required
            />
          </Field>

          <SubmitButton loading={loading}>
            {loading ? 'Checking...' : '🔍 Check Status'}
          </SubmitButton>
        </form>
      </Card>

      {/* Response Section */}
      {responseData && (
        <Card maxWidth={700} style={{ marginTop: 24 }}>
          <PageTitle icon="📋" title="Status Response" />
          <ResponseTable data={responseData} />
          <JsonBlock data={responseData} label="Raw JSON Response" />
          <div style={{ marginTop: 16 }}>
            <button
              onClick={() => setResponseData(null)}
              style={{
                padding: '8px 16px',
                background: 'transparent',
                border: '1.5px solid var(--border)',
                borderRadius: 7,
                color: 'var(--text-muted)',
                cursor: 'pointer',
                fontSize: '0.85rem',
                fontWeight: 600,
              }}
            >
              ← New Check
            </button>
          </div>
        </Card>
      )}
    </PageShell>
  );
}
