const BASE_URL = '/api';

async function fetchJson(url, options = {}) {
  const res = await fetch(BASE_URL + url, {
    headers: { 'Content-Type': 'application/json', ...options.headers },
    ...options,
  });
  const data = await res.json();
  if (!res.ok) {
    throw new Error(data.error || `HTTP ${res.status}`);
  }
  return data;
}

export const api = {
  getConfig: ()         => fetchJson('/config'),
  generateTxn: ()       => fetchJson('/generate-txn'),

  submitPayment: (body) => fetchJson('/payment/submit', {
    method: 'POST',
    body: JSON.stringify(body),
  }),

  checkStatus: (body)   => fetchJson('/status/submit', {
    method: 'POST',
    body: JSON.stringify(body),
  }),

  initiateRefund: (body) => fetchJson('/refund/submit', {
    method: 'POST',
    body: JSON.stringify(body),
  }),
};
