import React from 'react';

/* ── Layout shell ── */
export function PageShell({ children }) {
  return (
    <div style={{
      minHeight: '100vh',
      background: 'var(--bg)',
      padding: '32px 16px',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
    }}>
      {children}
    </div>
  );
}

/* ── Card ── */
export function Card({ children, maxWidth = 500, style = {} }) {
  return (
    <div style={{
      background: 'var(--surface)',
      borderRadius: 'var(--radius)',
      boxShadow: 'var(--shadow)',
      padding: '36px 40px',
      width: '100%',
      maxWidth,
      ...style,
    }}>
      {children}
    </div>
  );
}

/* ── Page Title ── */
export function PageTitle({ icon, title, subtitle }) {
  return (
    <div style={{ textAlign: 'center', marginBottom: 28 }}>
      {icon && <div style={{ fontSize: 36, marginBottom: 8 }}>{icon}</div>}
      <h2 style={{
        fontFamily: "'Space Grotesk', sans-serif",
        fontSize: '1.5rem',
        fontWeight: 700,
        color: 'var(--text)',
        marginBottom: subtitle ? 6 : 0,
      }}>
        {title}
      </h2>
      {subtitle && (
        <p style={{ color: 'var(--text-muted)', fontSize: '0.875rem' }}>{subtitle}</p>
      )}
    </div>
  );
}

/* ── Form Field ── */
export function Field({ label, children, required }) {
  return (
    <div style={{ marginBottom: 16 }}>
      <label style={{
        display: 'block',
        fontSize: '0.8rem',
        fontWeight: 600,
        color: 'var(--text-muted)',
        marginBottom: 5,
        textTransform: 'uppercase',
        letterSpacing: '0.04em',
      }}>
        {label}{required && <span style={{ color: 'var(--accent)', marginLeft: 2 }}>*</span>}
      </label>
      {children}
    </div>
  );
}

const inputBase = {
  width: '100%',
  padding: '10px 13px',
  border: '1.5px solid var(--border)',
  borderRadius: 7,
  fontSize: '0.95rem',
  color: 'var(--text)',
  background: '#fff',
  transition: 'border-color 0.2s',
  outline: 'none',
};

/* ── Input ── */
export function Input({ readOnly, ...props }) {
  return (
    <input
      style={{
        ...inputBase,
        background: readOnly ? '#f5f7fa' : '#fff',
        color: readOnly ? 'var(--text-muted)' : 'var(--text)',
        cursor: readOnly ? 'default' : 'text',
      }}
      readOnly={readOnly}
      onFocus={e => { if (!readOnly) e.target.style.borderColor = 'var(--primary)'; }}
      onBlur={e => { e.target.style.borderColor = 'var(--border)'; }}
      {...props}
    />
  );
}

/* ── Select ── */
export function Select({ children, ...props }) {
  return (
    <select
      style={{
        ...inputBase,
        cursor: 'pointer',
        appearance: 'none',
        backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='8' viewBox='0 0 12 8'%3E%3Cpath d='M1 1l5 5 5-5' stroke='%235a6a7e' stroke-width='1.5' fill='none' stroke-linecap='round'/%3E%3C/svg%3E")`,
        backgroundRepeat: 'no-repeat',
        backgroundPosition: 'right 12px center',
        paddingRight: 36,
      }}
      onFocus={e => { e.target.style.borderColor = 'var(--primary)'; }}
      onBlur={e => { e.target.style.borderColor = 'var(--border)'; }}
      {...props}
    >
      {children}
    </select>
  );
}

/* ── Submit Button ── */
export function SubmitButton({ loading, children, ...props }) {
  return (
    <button
      type="submit"
      disabled={loading}
      style={{
        width: '100%',
        padding: '13px',
        background: loading ? '#7aa7d4' : 'var(--primary)',
        color: '#fff',
        border: 'none',
        borderRadius: 8,
        fontSize: '1rem',
        fontWeight: 700,
        fontFamily: "'Space Grotesk', sans-serif",
        cursor: loading ? 'not-allowed' : 'pointer',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 10,
        transition: 'background 0.2s, transform 0.1s',
        marginTop: 8,
      }}
      onMouseEnter={e => { if (!loading) e.target.style.background = 'var(--primary-dk)'; }}
      onMouseLeave={e => { if (!loading) e.target.style.background = 'var(--primary)'; }}
      onMouseDown={e => { if (!loading) e.target.style.transform = 'scale(0.98)'; }}
      onMouseUp={e => { e.target.style.transform = 'scale(1)'; }}
      {...props}
    >
      {loading ? <Spinner /> : null}
      {children}
    </button>
  );
}

function Spinner() {
  return (
    <span style={{
      width: 18, height: 18,
      border: '2.5px solid rgba(255,255,255,0.4)',
      borderTopColor: '#fff',
      borderRadius: '50%',
      display: 'inline-block',
      animation: 'spin 0.7s linear infinite',
    }} />
  );
}

/* ── Alert Boxes ── */
export function Alert({ type = 'error', children }) {
  const styles = {
    error:   { bg: 'var(--error-bg)',   border: '#f5c6c6', color: 'var(--error)',   icon: '⚠️' },
    success: { bg: 'var(--success-bg)', border: '#a7d7b8', color: 'var(--success)', icon: '✅' },
    warning: { bg: 'var(--warn-bg)',    border: '#fcd34d', color: 'var(--warn)',     icon: '⚡' },
    info:    { bg: 'var(--primary-lt)', border: '#93c5fd', color: 'var(--primary)', icon: 'ℹ️' },
  };
  const s = styles[type] || styles.info;
  return (
    <div style={{
      background: s.bg,
      border: `1px solid ${s.border}`,
      color: s.color,
      borderRadius: 8,
      padding: '12px 15px',
      fontSize: '0.9rem',
      display: 'flex',
      gap: 8,
      alignItems: 'flex-start',
      marginBottom: 16,
    }}>
      <span>{s.icon}</span>
      <span>{children}</span>
    </div>
  );
}

/* ── Response Table ── */
export function ResponseTable({ data }) {
  if (!data || typeof data !== 'object') return null;
  const entries = Object.entries(data);
  if (!entries.length) return <p style={{ color: 'var(--text-muted)' }}>No data.</p>;

  return (
    <div style={{ overflowX: 'auto' }}>
      <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.88rem' }}>
        <thead>
          <tr>
            {['Parameter', 'Value'].map(h => (
              <th key={h} style={{
                background: 'var(--primary)',
                color: '#fff',
                padding: '10px 14px',
                textAlign: 'left',
                fontFamily: "'Space Grotesk', sans-serif",
                fontWeight: 600,
                fontSize: '0.82rem',
                textTransform: 'uppercase',
                letterSpacing: '0.04em',
              }}>{h}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {entries.map(([key, val], i) => (
            <tr key={key} style={{ background: i % 2 === 0 ? '#fff' : '#f7fafc' }}>
              <td style={{
                padding: '9px 14px',
                borderBottom: '1px solid var(--border)',
                fontWeight: 600,
                color: 'var(--text-muted)',
                whiteSpace: 'nowrap',
              }}>{key}</td>
              <td style={{
                padding: '9px 14px',
                borderBottom: '1px solid var(--border)',
                wordBreak: 'break-all',
                color: 'var(--text)',
              }}>
                {typeof val === 'object' ? JSON.stringify(val) : String(val)}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

/* ── JSON Preview ── */
export function JsonBlock({ data, label }) {
  return (
    <div style={{ marginTop: 20 }}>
      {label && <h4 style={{ fontSize: '0.85rem', fontWeight: 600, color: 'var(--text-muted)', marginBottom: 6, textTransform: 'uppercase', letterSpacing: '0.04em' }}>{label}</h4>}
      <pre style={{
        background: '#1e2a3b',
        color: '#a8d8a8',
        padding: 16,
        borderRadius: 8,
        overflowX: 'auto',
        fontSize: '0.82rem',
        lineHeight: 1.6,
        whiteSpace: 'pre-wrap',
        wordBreak: 'break-all',
      }}>
        {typeof data === 'string' ? data : JSON.stringify(data, null, 2)}
      </pre>
    </div>
  );
}

/* ── Divider ── */
export function Divider({ label }) {
  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 12,
      margin: '20px 0', color: 'var(--text-muted)', fontSize: '0.8rem',
    }}>
      <div style={{ flex: 1, height: 1, background: 'var(--border)' }} />
      {label && <span style={{ fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.05em' }}>{label}</span>}
      <div style={{ flex: 1, height: 1, background: 'var(--border)' }} />
    </div>
  );
}

/* Inject keyframes once */
if (typeof document !== 'undefined' && !document.getElementById('pg-keyframes')) {
  const style = document.createElement('style');
  style.id = 'pg-keyframes';
  style.textContent = `@keyframes spin { to { transform: rotate(360deg); } }`;
  document.head.appendChild(style);
}
