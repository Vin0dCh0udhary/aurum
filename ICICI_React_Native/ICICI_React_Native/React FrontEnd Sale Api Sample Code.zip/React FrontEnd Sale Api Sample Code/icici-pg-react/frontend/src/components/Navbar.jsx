import React from 'react';
import { NavLink } from 'react-router-dom';

const navItems = [
  { to: '/',       label: 'Initiate Sale',   icon: '💳' },
  { to: '/status', label: 'Check Status',    icon: '🔍' },
  { to: '/refund', label: 'Initiate Refund', icon: '↩️' },
];

export default function Navbar() {
  return (
    <nav style={{
      background: 'var(--primary)',
      boxShadow: '0 2px 12px rgba(0,76,151,0.25)',
      position: 'sticky',
      top: 0,
      zIndex: 100,
    }}>
      <div style={{
        maxWidth: 900,
        margin: '0 auto',
        padding: '0 20px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        flexWrap: 'wrap',
        gap: 8,
      }}>
        {/* Logo / Brand */}
        <div style={{
          display: 'flex', alignItems: 'center', gap: 10,
          padding: '14px 0',
        }}>
          <div style={{
            width: 36, height: 36,
            background: '#F37027',
            borderRadius: 8,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: 18, fontWeight: 800,
            fontFamily: "'Space Grotesk', sans-serif",
            color: '#fff',
            letterSpacing: '-1px',
          }}>IC</div>
          <span style={{
            color: '#fff',
            fontFamily: "'Space Grotesk', sans-serif",
            fontWeight: 700,
            fontSize: '1rem',
            letterSpacing: '-0.02em',
          }}>
            ICICI <span style={{ color: '#F37027' }}>PG</span> Integration
          </span>
        </div>

        {/* Nav links */}
        <div style={{ display: 'flex', gap: 4, padding: '8px 0', flexWrap: 'wrap' }}>
          {navItems.map(({ to, label, icon }) => (
            <NavLink
              key={to}
              to={to}
              end={to === '/'}
              style={({ isActive }) => ({
                display: 'flex', alignItems: 'center', gap: 6,
                padding: '7px 14px',
                borderRadius: 7,
                color: isActive ? 'var(--primary)' : 'rgba(255,255,255,0.85)',
                background: isActive ? '#fff' : 'transparent',
                fontWeight: isActive ? 700 : 500,
                fontSize: '0.88rem',
                textDecoration: 'none',
                transition: 'all 0.18s',
                fontFamily: "'DM Sans', sans-serif",
              })}
            >
              <span>{icon}</span>
              <span>{label}</span>
            </NavLink>
          ))}
        </div>
      </div>
    </nav>
  );
}
