import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Navbar           from './components/Navbar.jsx';
import InitiateSale     from './pages/InitiateSale.jsx';
import PaymentResponse  from './pages/PaymentResponse.jsx';
import StatusCheck      from './pages/StatusCheck.jsx';
import InitiateRefund   from './pages/InitiateRefund.jsx';
import ErrorPage        from './pages/ErrorPage.jsx';

export default function App() {
  return (
    <>
      <Navbar />
      <Routes>
        <Route path="/"                   element={<InitiateSale />} />
        <Route path="/payment/response"   element={<PaymentResponse />} />
        <Route path="/status"             element={<StatusCheck />} />
        <Route path="/refund"             element={<InitiateRefund />} />
        <Route path="/error"              element={<ErrorPage />} />
        <Route path="*"                   element={<InitiateSale />} />
      </Routes>
    </>
  );
}
