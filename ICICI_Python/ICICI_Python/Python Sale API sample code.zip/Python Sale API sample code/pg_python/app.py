"""
Payment Gateway - Python/Flask version
Equivalent of the PHP payment gateway implementation.
Run: python app.py
Then open: http://localhost:5000
"""

import hashlib
import hmac
import json
import time
import random
import requests

from datetime import datetime
from flask import Flask, render_template, request, redirect, jsonify
from zoneinfo import ZoneInfo

app = Flask(__name__)
app.secret_key = "pg_secret_key_change_in_prod"

# ─── CONFIG (mirrors config.php) ─────────────────────────────────────────────

CONFIG = {
    "UAT": {
        "merchant_id":    "100000000007164",
        "aggregator_id":  "A100000000007164",
        "key":            "db06cca0-838b-4e01-8b20-6ac446ffb6bd",
        "api": {
            "initiate_sale": "https://pgpayuat.icicibank.com/tsp/pg/api/v2/initiateSale",
            "status":        "https://pgpayuat.icicibank.com/tsp/pg/api/command",
            "refund":        "https://pgpayuat.icicibank.com/tsp/pg/api/command",
        },
        "return_url": "http://localhost:5000/payment_response",
    },
    "LIVE": {
        "merchant_id":    "YourMerchantID",
        "aggregator_id":  "YourAggregatorID",
        "key":            "YourSecretKey",
        "api": {
            "initiate_sale": "https://pgpay.icicibank.com/pg/api/v2/initiateSale",
            "status":        "https://pgpay.icicibank.com/pg/api/command",
            "refund":        "https://pgpay.icicibank.com/pg/api/command",
        },
        "return_url": "http://localhost:5000/payment_response",
    },
    "timezone": "Asia/Kolkata",
}

# ─── HELPERS ──────────────────────────────────────────────────────────────────

def get_ist_now():
    return datetime.now(ZoneInfo(CONFIG["timezone"]))

def gen_txn_id():
    return "test" + get_ist_now().strftime("%Y%m%d%H%M%S")

def gen_txn_date():
    return get_ist_now().strftime("%Y%m%d%H%M%S")

def make_hmac(data_to_hash: str, secret: str) -> str:
    return hmac.new(
        secret.encode("utf-8"),
        data_to_hash.encode("utf-8"),
        hashlib.sha256,
    ).hexdigest()

# ─── ROUTES ───────────────────────────────────────────────────────────────────

@app.route("/")
def index():
    """Landing page – mirrors index.php"""
    return render_template("index.html")


# ── PAYMENT INITIATION ───────────────────────────────────────────────────────

@app.route("/initiatesale")
def initiatesale():
    """Payment form – mirrors initiatesale.php"""
    txn_id   = gen_txn_id()
    txn_date = gen_txn_date()
    return render_template(
        "initiatesale.html",
        config=CONFIG,
        txn_id=txn_id,
        txn_date=txn_date,
    )


@app.route("/submit_payment", methods=["POST"])
def submit_payment():
    """Process payment – mirrors submit_payment.php"""
    env = request.form.get("environment", "UAT")
    if env not in CONFIG:
        return "Invalid environment selected.", 400

    cfg          = CONFIG[env]
    merchant_id  = cfg["merchant_id"]
    aggregator_id = cfg["aggregator_id"]
    secret_key   = cfg["key"]
    api_endpoint = cfg["api"]["initiate_sale"]
    return_url   = cfg["return_url"]

    name         = request.form.get("name", "")
    mobile       = request.form.get("mobile", "")
    email        = request.form.get("email", "")
    amount       = request.form.get("amount", "")
    txn_id       = request.form.get("transactionid", gen_txn_id())
    txn_date     = request.form.get("txndate", gen_txn_date())
    addl_param1  = request.form.get("addlParam1", "")
    addl_param2  = request.form.get("addlParam2", "")
    udf1         = request.form.get("udf1", "").strip()
    udf2         = request.form.get("udf2", "").strip()
    udf3         = request.form.get("udf3", "").strip()

    # Build base payload
    data = {
        "addlParam1":       addl_param1,
        "addlParam2":       addl_param2,
        "aggregatorID":     aggregator_id,
        "amount":           amount,
        "currencyCode":     "356",
        "customerEmailID":  email,
        "customerMobileNo": mobile,
        "customerName":     name,
        "merchantId":       merchant_id,
        "merchantTxnNo":    txn_id,
        "payType":          "0",
        "returnURL":        return_url,
        "transactionType":  "SALE",
        "txnDate":          txn_date,
    }

    # Add udfFields if any provided
    has_udf = any([udf1, udf2, udf3])
    if has_udf:
        data["udfFields"] = [{"udf21": udf1, "udf22": udf2, "udf23": udf3}]

    # Sort alphabetically by key
    sorted_data = dict(sorted(data.items()))

    # Build hash input string
    data_to_hash = ""
    for key, value in sorted_data.items():
        if key == "udfFields" and isinstance(value, list):
            data_to_hash += json.dumps(value, separators=(",", ":"), ensure_ascii=False)
        else:
            data_to_hash += str(value)

    secure_hash = make_hmac(data_to_hash, secret_key)
    sorted_data["secureHash"] = secure_hash

    json_payload = json.dumps(sorted_data, indent=2, ensure_ascii=False)

    # POST to ICICI PG
    try:
        resp = requests.post(
            api_endpoint,
            data=json_payload,
            headers={"Content-Type": "application/json"},
            timeout=30,
        )
        response_data = resp.json()
    except Exception as e:
        return render_template(
            "error.html",
            error=str(e),
            json_payload=json_payload,
            data_to_hash=data_to_hash,
        )

    if "redirectURI" in response_data and "tranCtx" in response_data:
        redirect_url = f"{response_data['redirectURI']}?tranCtx={response_data['tranCtx']}"
        return redirect(redirect_url)
    else:
        return render_template(
            "error.html",
            error="Missing redirectURI or tranCtx in response.",
            response_data=response_data,
            json_payload=json_payload,
            data_to_hash=data_to_hash,
        )


# ── PAYMENT RESPONSE ─────────────────────────────────────────────────────────

@app.route("/payment_response", methods=["POST", "GET"])
def payment_response():
    """Display payment callback – mirrors payment_response.php"""
    post_data = request.form.to_dict() if request.method == "POST" else request.args.to_dict()
    return render_template("payment_response.html", post_data=post_data)


# ── STATUS CHECK ──────────────────────────────────────────────────────────────

@app.route("/statuscheck")
def statuscheck():
    """Status check form – mirrors statuscheck.php"""
    return render_template("statuscheck.html", config=CONFIG)


@app.route("/submit_status", methods=["POST"])
def submit_status():
    """Process status check – mirrors submit_status.php"""
    env = request.form.get("environment", "UAT")
    cfg = CONFIG[env]

    merchant_id   = cfg["merchant_id"]
    aggregator_id = cfg["aggregator_id"]
    secret_key    = cfg["key"]
    status_url    = cfg["api"]["status"]

    txn_id      = request.form.get("transactionid", "")
    original_id = request.form.get("originalid", "")
    txn_type    = "STATUS"

    data = {
        "aggregatorID":    aggregator_id,
        "merchantId":      merchant_id,
        "merchantTxnNo":   txn_id,
        "originalTxnNo":   original_id,
        "transactionType": txn_type,
    }

    sorted_data  = dict(sorted(data.items()))
    data_to_hash = "".join(sorted_data.values())
    secure_hash  = make_hmac(data_to_hash, secret_key)

    request_data = {**sorted_data, "secureHash": secure_hash}
    json_payload = json.dumps(request_data)

    try:
        resp = requests.post(
            status_url,
            data=json_payload,
            headers={"Content-Type": "application/json"},
            timeout=30,
        )
        response_data = resp.json()
    except Exception as e:
        return render_template("error.html", error=str(e))

    return render_template(
        "status_response.html",
        response_data=response_data,
        request_data=request_data,
    )


# ── REFUND ────────────────────────────────────────────────────────────────────

@app.route("/initiaterefund")
def initiaterefund():
    """Refund form – mirrors initiaterefund.php"""
    txn_id = gen_txn_id()
    return render_template("initiaterefund.html", config=CONFIG, txn_id=txn_id)


@app.route("/submit_refund", methods=["POST"])
def submit_refund():
    """Process refund – mirrors submit_refund.php"""
    env = request.form.get("environment", "UAT")
    cfg = CONFIG[env]

    merchant_id   = cfg["merchant_id"]
    aggregator_id = cfg["aggregator_id"]
    secret_key    = cfg["key"]
    refund_url    = cfg["api"]["refund"]

    txn_id      = request.form.get("transactionid", gen_txn_id())
    original_id = request.form.get("originalid", "")
    amount      = f"{float(request.form.get('amount', 0)):.2f}"
    txn_type    = "REFUND"

    data = {
        "aggregatorID":    aggregator_id,
        "amount":          amount,
        "merchantId":      merchant_id,
        "merchantTxnNo":   txn_id,
        "originalTxnNo":   original_id,
        "transactionType": txn_type,
    }

    sorted_data  = dict(sorted(data.items()))
    data_to_hash = "".join(sorted_data.values())
    secure_hash  = make_hmac(data_to_hash, secret_key)

    request_data = {**sorted_data, "secureHash": secure_hash}
    json_payload = json.dumps(request_data)

    try:
        resp = requests.post(
            refund_url,
            data=json_payload,
            headers={"Content-Type": "application/json"},
            timeout=30,
        )
        response_data = resp.json()
    except Exception as e:
        return render_template("error.html", error=str(e))

    return render_template(
        "refund_response.html",
        response_data=response_data,
        request_data=request_data,
    )


# ── UPI QR ────────────────────────────────────────────────────────────────────

@app.route("/paymentqr", methods=["GET", "POST"])
def paymentqr():
    """UPI QR code – mirrors paymentqr.php"""
    upi_qr       = None
    error        = None
    merchant_ref = None
    amount       = None

    SECRET_KEY  = "abc"
    API_URL     = "https://qa.phicommerce.com/pg/api/generateQR"
    MERCHANT_ID = "T_08883"

    if request.method == "POST":
        amount       = request.form.get("amount", "").strip()
        email_id     = request.form.get("emailID", "").strip()
        merchant_ref = str(int(time.time())) + str(random.randint(100, 999))

        req_data = {
            "amount":        amount,
            "currency":      "356",
            "emailID":       email_id,
            "merchantId":    MERCHANT_ID,
            "merchantRefNo": merchant_ref,
            "requestType":   "UPIQR",
        }

        sorted_req   = dict(sorted(req_data.items()))
        plain_hash   = "".join(sorted_req.values())
        secure_hash  = make_hmac(plain_hash, SECRET_KEY)

        post_data = {**sorted_req, "secureHash": secure_hash}

        try:
            resp = requests.post(
                API_URL,
                data=post_data,
                headers={"Content-Type": "application/x-www-form-urlencoded"},
                timeout=30,
            )
            resp_json = resp.json()
            if resp.status_code == 200 and "respBody" in resp_json and "upiQR" in resp_json["respBody"]:
                upi_qr = resp_json["respBody"]["upiQR"]
            else:
                error = "API Error: " + resp_json.get("respHeader", {}).get("desc", "Unknown error")
        except Exception as e:
            error = str(e)

    return render_template(
        "paymentqr.html",
        upi_qr=upi_qr,
        error=error,
        merchant_ref=merchant_ref,
        amount=amount,
    )


# ── GET IP ────────────────────────────────────────────────────────────────────

@app.route("/get_ip")
def get_ip():
    try:
        ip = requests.get("https://api.ipify.org", timeout=5).text
        return f"Server Public IP: {ip}"
    except Exception as e:
        return f"Error: {e}"


# ─── ENTRY POINT ──────────────────────────────────────────────────────────────

if __name__ == "__main__":
    print("Starting Payment Gateway on http://localhost:5000")
    app.run(debug=True, port=5000)
